
// Big Offer Client Interactivity Script
const UNIT_PRICE = 200;
let currentQty = 1;

// Image Gallery
function setMainImage(src) {
  const mainImg = document.getElementById('main-image');
  if (mainImg) mainImg.src = src;
}

// Countdown Timer
(function initTimer() {
  let totalSeconds = 2 * 3600 + 48 * 60 + 35;
  const hoursEl = document.getElementById('timer-hours');
  const minEl = document.getElementById('timer-minutes');
  const secEl = document.getElementById('timer-seconds');

  setInterval(() => {
    if (totalSeconds > 0) totalSeconds--;
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    if (hoursEl) hoursEl.textContent = String(h).padStart(2, '0');
    if (minEl) minEl.textContent = String(m).padStart(2, '0');
    if (secEl) secEl.textContent = String(s).padStart(2, '0');
  }, 1000);
})();

// Quantity update
function updateQty(delta) {
  currentQty = Math.max(1, currentQty + delta);
  const qtyEl = document.getElementById('order-qty');
  const totalDisplay = document.getElementById('total-price-display');
  const stickyPrice = document.getElementById('sticky-price');
  if (qtyEl) qtyEl.textContent = String(currentQty);
  const total = currentQty * UNIT_PRICE;
  if (totalDisplay) totalDisplay.textContent = total + ' DH';
  if (stickyPrice) stickyPrice.textContent = total;
}

// Modal open/close
function openOrderModal() {
  const modal = document.getElementById('order-modal-backdrop');
  if (modal) {
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }
}

function closeOrderModal() {
  const modal = document.getElementById('order-modal-backdrop');
  if (modal) {
    modal.classList.add('hidden');
    document.body.style.overflow = '';
  }
}

// Moroccan Phone Validation
function isValidMoroccanPhone(phone) {
  const clean = (phone || '').replace(/[\s\-\(\)\.]/g, '');
  return /^(?:(?:\+|00)212|0)?[5-7]\d{8}$/.test(clean);
}

// Moroccan Cities Dropdown Handler for Main Form
function showCityDropdown() {
  const list = document.getElementById('city-dropdown-list');
  if (!list) return;
  filterCityDropdown();
  list.classList.remove('hidden');
}

function filterCityDropdown() {
  const input = document.getElementById('city-search-input');
  const list = document.getElementById('city-dropdown-list');
  if (!input || !list) return;
  const q = (input.value || '').trim().toLowerCase();
  const cities = window.MOROCCO_CITIES || [];
  const filtered = q ? cities.filter(c => c.toLowerCase().includes(q)) : cities;

  list.innerHTML = '';
  if (filtered.length === 0) {
    list.innerHTML = '<div class="p-3 text-xs text-neutral-500 text-center">لم يتم العثور على هذه المدينة</div>';
  } else {
    filtered.slice(0, 30).forEach(city => {
      const item = document.createElement('div');
      item.className = 'px-4 py-2.5 text-xs font-bold text-neutral-800 hover:bg-[#FFF3EB] hover:text-[#FF6B00] cursor-pointer transition-colors';
      item.textContent = city;
      item.onclick = () => selectCity(city);
      list.appendChild(item);
    });
  }
  list.classList.remove('hidden');
}

function selectCity(city) {
  const input = document.getElementById('city-search-input');
  const hidden = document.getElementById('selected-city');
  const list = document.getElementById('city-dropdown-list');
  const status = document.getElementById('city-status');
  if (input) input.value = city;
  if (hidden) hidden.value = city;
  if (list) list.classList.add('hidden');
  if (status) {
    status.textContent = '✓ تم تحديد المدينة';
    status.className = 'text-[11px] font-bold text-[#129A56]';
  }
  checkFormValidity();
}

// Check Main Form Validity & Toggle Active/Inactive Submit Button
function checkFormValidity() {
  const name = (document.getElementById('customer-name')?.value || '').trim();
  const phone = (document.getElementById('customer-phone')?.value || '').trim();
  const city = (document.getElementById('selected-city')?.value || document.getElementById('city-search-input')?.value || '').trim();
  const address = (document.getElementById('customer-address')?.value || '').trim();

  const isNameValid = name.length >= 2;
  const isPhoneValid = isValidMoroccanPhone(phone);
  const isCityValid = city.length >= 2;
  const isAddressValid = address.length >= 3;

  const isValid = isNameValid && isPhoneValid && isCityValid && isAddressValid;
  const btn = document.getElementById('submit-order-button');
  const btnText = document.getElementById('submit-button-text');

  if (btn && btnText) {
    if (isValid) {
      btn.disabled = false;
      btn.className = 'w-full py-4 px-6 rounded-2xl font-black text-base sm:text-lg transition-all transform flex items-center justify-center gap-2 bg-[#FF6B00] hover:bg-[#E05300] active:scale-[0.98] text-white shadow-lg shadow-orange-500/25 cursor-pointer animate-pulse hover:animate-none';
      btnText.textContent = 'تأكيد الطلب الآن — الدفع عند الاستلام';
    } else {
      btn.disabled = true;
      btn.className = 'w-full py-4 px-6 rounded-2xl font-black text-base sm:text-lg transition-all transform flex items-center justify-center gap-2 bg-neutral-300 text-neutral-500 cursor-not-allowed opacity-80 shadow-none';
      btnText.textContent = 'الرجاء إدخال معلوماتك لتأكيد الطلب';
    }
  }
}

// Modal City Dropdown Handlers
function showModalCityDropdown() {
  const list = document.getElementById('modal-city-dropdown');
  if (!list) return;
  filterModalCityDropdown();
  list.classList.remove('hidden');
}

function filterModalCityDropdown() {
  const input = document.getElementById('modal-city-search');
  const list = document.getElementById('modal-city-dropdown');
  if (!input || !list) return;
  const q = (input.value || '').trim().toLowerCase();
  const cities = window.MOROCCO_CITIES || [];
  const filtered = q ? cities.filter(c => c.toLowerCase().includes(q)) : cities;

  list.innerHTML = '';
  filtered.slice(0, 30).forEach(city => {
    const item = document.createElement('div');
    item.className = 'px-3.5 py-2 text-xs font-bold text-neutral-800 hover:bg-[#FFF3EB] hover:text-[#FF6B00] cursor-pointer';
    item.textContent = city;
    item.onclick = () => selectModalCity(city);
    list.appendChild(item);
  });
  list.classList.remove('hidden');
}

function selectModalCity(city) {
  const input = document.getElementById('modal-city-search');
  const hidden = document.getElementById('modal-selected-city');
  const list = document.getElementById('modal-city-dropdown');
  if (input) input.value = city;
  if (hidden) hidden.value = city;
  if (list) list.classList.add('hidden');
  checkModalFormValidity();
}

// Check Modal Form Validity & Toggle Active/Inactive Submit Button
function checkModalFormValidity() {
  const name = (document.getElementById('modal-customer-name')?.value || '').trim();
  const phone = (document.getElementById('modal-customer-phone')?.value || '').trim();
  const city = (document.getElementById('modal-selected-city')?.value || document.getElementById('modal-city-search')?.value || '').trim();
  const address = (document.getElementById('modal-customer-address')?.value || '').trim();

  const isNameValid = name.length >= 2;
  const isPhoneValid = isValidMoroccanPhone(phone);
  const isCityValid = city.length >= 2;
  const isAddressValid = address.length >= 3;

  const isValid = isNameValid && isPhoneValid && isCityValid && isAddressValid;
  const btn = document.getElementById('modal-submit-button');
  const btnText = document.getElementById('modal-submit-text');

  if (btn && btnText) {
    if (isValid) {
      btn.disabled = false;
      btn.className = 'w-full py-3.5 px-5 rounded-2xl font-black text-sm sm:text-base transition-all flex items-center justify-center gap-2 bg-[#FF6B00] hover:bg-[#E05300] active:scale-[0.98] text-white shadow-md cursor-pointer animate-pulse';
      btnText.textContent = 'تأكيد الطلب الآن (الدفع عند الاستلام)';
    } else {
      btn.disabled = true;
      btn.className = 'w-full py-3.5 px-5 rounded-2xl font-black text-sm sm:text-base transition-all flex items-center justify-center gap-2 bg-neutral-300 text-neutral-500 cursor-not-allowed opacity-80 shadow-none';
      btnText.textContent = 'الرجاء إدخال معلوماتك لتأكيد الطلب';
    }
  }
}

// Close dropdowns on outside click
document.addEventListener('click', (e) => {
  const cityInput = document.getElementById('city-search-input');
  const cityList = document.getElementById('city-dropdown-list');
  if (cityList && cityInput && !cityInput.contains(e.target) && !cityList.contains(e.target)) {
    cityList.classList.add('hidden');
  }

  const modalInput = document.getElementById('modal-city-search');
  const modalList = document.getElementById('modal-city-dropdown');
  if (modalList && modalInput && !modalInput.contains(e.target) && !modalList.contains(e.target)) {
    modalList.classList.add('hidden');
  }
});

// Form Submit Handlers
function handleFormSubmit(e) {
  e.preventDefault();
  const btn = document.getElementById('submit-order-button');
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '<span>جاري تأكيد الطلب...</span>';
  }

  setTimeout(() => {
    const form = document.getElementById('cod-order-form');
    const success = document.getElementById('order-success-screen');
    const orderId = 'COD-' + Math.floor(1000 + Math.random() * 9000);
    const idEl = document.getElementById('success-order-id');
    if (idEl) idEl.textContent = orderId;
    if (form) form.classList.add('hidden');
    if (success) success.classList.remove('hidden');

    // Trigger Analytics / Gtag
    if (typeof gtag === 'function') {
      gtag('event', 'purchase', {
        transaction_id: orderId,
        value: currentQty * UNIT_PRICE,
        currency: 'MAD'
      });
    }
  }, 600);
}

function handleModalFormSubmit(e) {
  e.preventDefault();
  const btn = document.getElementById('modal-submit-button');
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '<span>جاري تأكيد الطلب...</span>';
  }

  setTimeout(() => {
    const form = document.getElementById('modal-order-form');
    const success = document.getElementById('modal-success-screen');
    if (form) form.classList.add('hidden');
    if (success) success.classList.remove('hidden');
  }, 600);
}
